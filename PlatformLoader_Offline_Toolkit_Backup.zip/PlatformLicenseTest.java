import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Arrays;

/**
 * PlatformLoader 许可证加解密与原生 JAR 兼容性测试套件
 */
public class PlatformLicenseTest {

    public static void main(String[] args) {
        System.out.println("===============================================================================");
        System.out.println("            PlatformLoader 许可证工具链与原生 JAR 兼容性测试");
        System.out.println("===============================================================================\n");

        int totalTests = 0;
        int passedTests = 0;

        // 测试用例数据 (2029-10-10 延期商业授权)
        String startDate = "281001";
        String licenseId = "07BD9C12A359";
        String productCode = "ALL";
        String rollbackVer = "2016.1";
        String licType = "4";
        String endDate = "291010";
        String email = "kikock1987@gmail.com";

        try {
            // -------------------------------------------------------------
            // 测试项 1: 组装 7 段许可证明文
            // -------------------------------------------------------------
            totalTests++;
            System.out.println("[测试 1] 组装 7 段许可证明文");
            String plain = PlatformLicenseTool.buildLicensePlain(
                    startDate, licenseId, productCode, rollbackVer, licType, endDate, email
            );
            String expectedPlain = startDate + "&" + licenseId + "&" + productCode + "&" + rollbackVer + "&" + licType + "&" + endDate + "&" + email;
            if (expectedPlain.equals(plain)) {
                System.out.println("  -> 组装明文: " + plain);
                System.out.println("  -> [PASS] 明文格式符合协议规范\n");
                passedTests++;
            } else {
                System.err.println("  -> [FAIL] 明文不匹配: " + plain + "\n");
            }

            // -------------------------------------------------------------
            // 测试项 2: Blowfish 对称加解密闭环验证
            // -------------------------------------------------------------
            totalTests++;
            System.out.println("[测试 2] Blowfish 对称加解密闭环验证 (密钥 MD5(\"iAvNG\"))");
            String cipher = PlatformLicenseTool.encryptBlowfish(plain);
            String decrypted = PlatformLicenseTool.decryptBlowfish(cipher);
            if (plain.equals(decrypted)) {
                System.out.println("  -> 加密后密文: " + cipher);
                System.out.println("  -> 解密后明文: " + decrypted);
                System.out.println("  -> [PASS] Blowfish 加解密可逆且无失真\n");
                passedTests++;
            } else {
                System.err.println("  -> [FAIL] 解密结果与原值不符\n");
            }

            // -------------------------------------------------------------
            // 测试项 3: Windows Preferences 混淆存储 (XOR + MIME Base64) 闭环
            // -------------------------------------------------------------
            totalTests++;
            System.out.println("[测试 3] Preferences 混淆编解码验证 (异或密钥: \"The Drive to Develop.\")");
            String prefEncoded = PlatformLicenseTool.encodeForPreferences(cipher);
            String restoredCipher = PlatformLicenseTool.decodeFromPreferences(prefEncoded);
            if (cipher.equals(restoredCipher)) {
                System.out.println("  -> 混淆存储值: " + prefEncoded.replace("\r", "").replace("\n", ""));
                System.out.println("  -> [PASS] Preferences 编解码还原准确\n");
                passedTests++;
            } else {
                System.err.println("  -> [FAIL] Preferences 混淆编解码失败\n");
            }

            // -------------------------------------------------------------
            // 测试项 4: 写入并读取 Windows Preferences 注册表节点 (双节点联动)
            // -------------------------------------------------------------
            totalTests++;
            System.out.println("[测试 4] 实际写入并回读 Windows Preferences (jetbrains/jba-tokens & jetprofile)");
            PlatformLicenseTool.saveLicenseToPreferences(plain);
            String readBack = PlatformLicenseTool.readLicenseFromPreferences();
            if (plain.equals(readBack)) {
                System.out.println("  -> 成功写入注册表: jetbrains/jba-tokens -> ALL_jba_access_token");
                System.out.println("  -> 从注册表读取还原: " + readBack);
                System.out.println("  -> [PASS] 注册表持久化写入与读取成功\n");
                passedTests++;
            } else {
                System.err.println("  -> [FAIL] 注册表读取值不匹配\n");
            }

            // -------------------------------------------------------------
            // 测试项 5: 解析 MANIFEST.MF 的 permanent_token
            // -------------------------------------------------------------
            totalTests++;
            System.out.println("[测试 5] 解析 MANIFEST.MF 中的 permanent_token 属性 (处理长行折行)");
            File manifestFile = new File("d:\\kikock_poject\\demo\\platform-loader-project\\src\\main\\resources\\META-INF\\MANIFEST.MF");
            if (manifestFile.exists()) {
                String tokenInManifest = PlatformLicenseTool.parseManifestToken(manifestFile);
                String tokenDecrypted = PlatformLicenseTool.decryptBlowfish(tokenInManifest);
                String[] pipe = tokenDecrypted.split("\\|");
                boolean valid = pipe.length == 2 && pipe[0].startsWith("perm-");
                if (valid) {
                    System.out.println("  -> 提取的 Token: " + tokenInManifest);
                    System.out.println("  -> 解密原始明文: " + tokenDecrypted);
                    System.out.println("  -> YouTrack Token: " + pipe[0]);
                    System.out.println("  -> 设备并发策略: " + pipe[1]);
                    System.out.println("  -> [PASS] MANIFEST.MF Token 解析成功\n");
                    passedTests++;
                } else {
                    System.err.println("  -> [FAIL] MANIFEST.MF Token 解密格式不符合预期\n");
                }
            } else {
                System.out.println("  -> [SKIP] MANIFEST.MF 文件不存在，跳过\n");
            }

            // -------------------------------------------------------------
            // 测试项 6: 原生 platform-loader.jar 真实字节码兼容性集成测试
            // -------------------------------------------------------------
            totalTests++;
            System.out.println("[测试 6] 原生 platform-loader.jar 真实字节码兼容性集成测试 (U.PLATFORMxUUID() : String[])");
            File jarFile = new File("d:\\kikock_poject\\demo\\platform-loader.jar");
            if (jarFile.exists()) {
                File stubsDir = new File("d:\\kikock_poject\\demo\\stubs");
                URLClassLoader loader = new URLClassLoader(
                        new URL[]{stubsDir.toURI().toURL(), jarFile.toURI().toURL()},
                        ClassLoader.getPlatformClassLoader()
                );
                Class<?> uClass = loader.loadClass("com.intellij.platform.runtime.repository.impl.U");
                Method readLicenseMethod = null;
                for (Method m : uClass.getDeclaredMethods()) {
                    if ("PLATFORMxUUID".equals(m.getName()) && m.getParameterCount() == 0 && m.getReturnType() == String[].class) {
                        readLicenseMethod = m;
                        break;
                    }
                }

                if (readLicenseMethod != null) {
                    readLicenseMethod.setAccessible(true);
                    String[] jarResult = (String[]) readLicenseMethod.invoke(null);
                    String rejoined = String.join("&", jarResult);
                    if (plain.equals(rejoined)) {
                        System.out.println("  -> 真实 U.class 反射调用方法: " + readLicenseMethod.getName() + "() : String[]");
                        System.out.println("  -> 原生 JAR 内部解密输出: " + Arrays.toString(jarResult));
                        System.out.println("  -> 与注入明文一致性校验: true");
                        System.out.println("  -> [PASS] 原生 JAR 100% 成功识别并解析我们注入的许可证！\n");
                        passedTests++;
                    } else {
                        System.err.println("  -> [FAIL] 原生 JAR 解析结果不一致: " + rejoined + "\n");
                    }
                } else {
                    System.err.println("  -> [FAIL] 未在 U.class 中找到无参 PLATFORMxUUID() 方法\n");
                }

                // -------------------------------------------------------------
                // 测试项 7: 动态切换任意自定义邮箱并断言原生 JAR 校验通过 (全自动双写自愈测试)
                // -------------------------------------------------------------
                totalTests++;
                System.out.println("[测试 7] 动态切换自定义邮箱并断言原生全流程授权 (U.PLATFORMxUUID(AbstractRequest))");
                
                // 确保环境变量包含合法 jba_permanent_token
                String token = PlatformLicenseTool.generatePermanentToken("perm-bG9uZw==.NTEtMTI=.MGVwjurrW1b83t5fKRGIc1FjSfH3rc", "0-3");
                System.setProperty("jba_permanent_token", token);

                Class<?> requestClass = loader.loadClass("com.jetbrains.ls.requests.ValidateLicenseRequest");
                Constructor<?> cons = requestClass.getConstructor();
                Object request = cons.newInstance();

                Method validateMethod = null;
                for (Method m : uClass.getDeclaredMethods()) {
                    if ("PLATFORMxUUID".equals(m.getName()) && m.getParameterCount() == 1 && m.getReturnType() == boolean.class) {
                        if (m.getParameterTypes()[0].getName().contains("AbstractRequest")) {
                            validateMethod = m;
                            break;
                        }
                    }
                }

                if (validateMethod != null) {
                    validateMethod.setAccessible(true);
                    String customTestEmail = "kikock@qq.com";
                    String customPlain = PlatformLicenseTool.buildLicensePlain(
                            startDate, licenseId, productCode, rollbackVer, licType, endDate, customTestEmail
                    );
                    // 写入自定义邮箱 (内部自动原子双写 jetprofile)
                    PlatformLicenseTool.saveLicenseToPreferences(customPlain);

                    boolean validResult = (boolean) validateMethod.invoke(null, request);
                    if (validResult) {
                        System.out.println("  -> 自定义任意邮箱: " + customTestEmail);
                        System.out.println("  -> 真实 U.class 许可证校验结果: " + validResult);
                        System.out.println("  -> [PASS] 双节点原子更新生效！自定义任意邮箱均可 100% 成功解锁商业授权！\n");
                        passedTests++;
                    } else {
                        System.err.println("  -> [FAIL] 校验失败: 邮箱变更后原生验证未通过\n");
                    }

                    // 测试完成后无感恢复默认配置
                    PlatformLicenseTool.saveLicenseToPreferences(plain);
                } else {
                    System.err.println("  -> [FAIL] 未找到入口方法 PLATFORMxUUID(AbstractRequest)\n");
                }
            } else {
                System.out.println("  -> [SKIP] platform-loader.jar 不存在，跳过\n");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("===============================================================================");
        System.out.println("测试统计: 总测试数 " + totalTests + " 项, 通过 " + passedTests + " 项, 失败 " + (totalTests - passedTests) + " 项");
        if (totalTests == passedTests) {
            System.out.println("测试状态: 全部用例通过 (ALL TESTS PASSED)");
        } else {
            System.out.println("测试状态: 存在未通过用例 (TESTS FAILED)");
        }
        System.out.println("===============================================================================");
    }
}

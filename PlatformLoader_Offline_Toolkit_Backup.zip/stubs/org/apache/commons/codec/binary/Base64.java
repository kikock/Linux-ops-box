package org.apache.commons.codec.binary;
public class Base64 {
    public static byte[] decodeBase64(byte[] b) { return java.util.Base64.getDecoder().decode(b); }
    public static byte[] encodeBase64(byte[] b) { return java.util.Base64.getEncoder().encode(b); }
}

package com.jetbrains.ls.responses;
public class EncodedAsset { public EncodedAsset(Object o) {} }

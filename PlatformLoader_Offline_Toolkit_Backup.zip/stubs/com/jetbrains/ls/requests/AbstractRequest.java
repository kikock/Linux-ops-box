package com.jetbrains.ls.requests;

public class AbstractRequest<T> {
    public String getProductCode() { return "II"; }
    public String getMachineId() { return "dummy-machine-id"; }
    public String getBuildNumber() { return "IU-242.21829.142"; }
    public String getAssetId() { return "asset-1"; }
    public int getVersion() { return 2024; }
}

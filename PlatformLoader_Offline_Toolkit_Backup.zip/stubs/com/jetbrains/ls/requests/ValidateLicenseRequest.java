package com.jetbrains.ls.requests;
public class ValidateLicenseRequest extends AbstractRequest<Object> {}

package com.jetbrains.ls.requests;
public class ObtainLicenseRequest extends AbstractRequest<Object> {}

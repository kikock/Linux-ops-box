package com.google.common.cache;
import java.util.concurrent.Callable;

public interface Cache<K, V> {
    V get(K key, Callable<? extends V> loader) throws Exception;
    V getIfPresent(Object key);
    void put(K key, V value);
}

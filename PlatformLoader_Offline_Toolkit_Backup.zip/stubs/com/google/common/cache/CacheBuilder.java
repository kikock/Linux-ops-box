package com.google.common.cache;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;

public class CacheBuilder<K, V> {
    public static CacheBuilder<Object, Object> newBuilder() { return new CacheBuilder<>(); }
    public CacheBuilder<K, V> maximumSize(long s) { return this; }
    public CacheBuilder<K, V> expireAfterWrite(long d, java.util.concurrent.TimeUnit u) { return this; }
    public <K1 extends K, V1 extends V> Cache<K1, V1> build() {
        return new Cache<K1, V1>() {
            private final ConcurrentHashMap<Object, Object> map = new ConcurrentHashMap<>();
            @Override
            public V1 get(K1 key, Callable<? extends V1> loader) throws Exception {
                Object val = map.get(key);
                if (val == null) {
                    val = loader.call();
                    if (val != null) map.put(key, val);
                }
                return (V1) val;
            }
            @Override
            public V1 getIfPresent(Object key) {
                return (V1) map.get(key);
            }
            @Override
            public void put(K1 key, V1 value) {
                if (value != null) map.put(key, value);
            }
        };
    }
}

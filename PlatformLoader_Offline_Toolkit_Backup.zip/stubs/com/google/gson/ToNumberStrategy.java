package com.google.gson;
public interface ToNumberStrategy {}

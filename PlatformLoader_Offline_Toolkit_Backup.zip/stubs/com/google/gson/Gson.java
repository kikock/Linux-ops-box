package com.google.gson;

public class Gson {
    @SuppressWarnings("unchecked")
    public <T> T fromJson(String json, Class<T> classOfT) {
        try {
            return classOfT.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    public <T> T fromJson(String json, java.lang.reflect.Type typeOfT) {
        return (T) new java.util.ArrayList<Object>();
    }

    public String toJson(Object src) {
        return "{}";
    }
}

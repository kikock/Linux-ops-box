package com.google.gson;
public class GsonBuilder {
    public GsonBuilder disableHtmlEscaping() { return this; }
    public GsonBuilder setObjectToNumberStrategy(ToNumberStrategy s) { return this; }
    public Gson create() { return new Gson(); }
}

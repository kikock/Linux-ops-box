package com.google.gson;
public enum ToNumberPolicy implements ToNumberStrategy { LONG_OR_DOUBLE }

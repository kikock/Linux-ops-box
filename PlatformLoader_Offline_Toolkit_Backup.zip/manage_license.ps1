<#
.SYNOPSIS
    PlatformLoader 企业授权管理脚本 (PowerShell 版)
#>

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Set-Location -Path $PSScriptRoot

function Show-Menu {
    Clear-Host
    Write-Host "===============================================================================" -ForegroundColor Cyan
    Write-Host "                   PlatformLoader 企业授权运维终端 (PowerShell)" -ForegroundColor Cyan
    Write-Host "===============================================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "   [1] 修改授权配置 (交互式修改到期时间、授权邮箱)" -ForegroundColor Yellow
    Write-Host "   [2] 一键编译并生效 (生成 class 字节码并自动写入注册表)" -ForegroundColor Green
    Write-Host "   [3] 运行原机验证回归测试 (调用原生 platform-loader.jar 验证 7 项用例)" -ForegroundColor Cyan
    Write-Host "   [4] 使用记事本直接打开 PlatformLicenseTool.java 源码编辑" -ForegroundColor White
    Write-Host "   [0] 退出" -ForegroundColor Gray
    Write-Host ""
    Write-Host "===============================================================================" -ForegroundColor Cyan
}

function Modify-Config {
    Clear-Host
    Write-Host "===============================================================================" -ForegroundColor Cyan
    Write-Host "                           【1. 修改授权配置参数】" -ForegroundColor Cyan
    Write-Host "===============================================================================" -ForegroundColor Cyan
    Write-Host ""

    $toolFile = Join-Path $PSScriptRoot "PlatformLicenseTool.java"
    $testFile = Join-Path $PSScriptRoot "PlatformLicenseTest.java"

    $content = Get-Content $toolFile -Raw -Encoding UTF8
    $currentEndDate = ""
    $currentEmail = ""

    if ($content -match 'String endDate\s*=\s*"(\d+)"') {
        $currentEndDate = $matches[1]
    }
    if ($content -match 'String email\s*=\s*"([^"]+)"') {
        $currentEmail = $matches[1]
    }

    Write-Host "当前配置参数：" -ForegroundColor White
    Write-Host "  -> 授权到期日 (endDate) : $currentEndDate" -ForegroundColor Green
    Write-Host "  -> 授权邮箱   (email)   : $currentEmail" -ForegroundColor Green
    Write-Host ""
    Write-Host "-------------------------------------------------------------------------------" -ForegroundColor Gray
    Write-Host "说明：直接按回车表示保持原值不变；输入新值按回车进行修改。" -ForegroundColor Gray
    Write-Host "-------------------------------------------------------------------------------" -ForegroundColor Gray

    $newEndDate = Read-Host "请输入新的到期时间 (格式 yyMMdd，例如 291010，回车跳过)"
    $newEmail = Read-Host "请输入新的授权邮箱 (例如 your_name@company.com，回车跳过)"

    if (-not [string]::IsNullOrWhiteSpace($newEndDate)) {
        $content = $content -replace 'String endDate\s*=\s*"\d+"', ('String endDate = "' + $newEndDate + '"')
        Set-Content -Path $toolFile -Value $content -Encoding UTF8

        if (Test-Path $testFile) {
            $testContent = Get-Content $testFile -Raw -Encoding UTF8
            $testContent = $testContent -replace 'String endDate\s*=\s*"\d+"', ('String endDate = "' + $newEndDate + '"')
            Set-Content -Path $testFile -Value $testContent -Encoding UTF8
        }
        Write-Host "[+] 已更新到期时间为: $newEndDate" -ForegroundColor Green
    }

    if (-not [string]::IsNullOrWhiteSpace($newEmail)) {
        $content = Get-Content $toolFile -Raw -Encoding UTF8
        $content = $content -replace 'String email\s*=\s*"[^"]+"', ('String email = "' + $newEmail + '"')
        Set-Content -Path $toolFile -Value $content -Encoding UTF8

        if (Test-Path $testFile) {
            $testContent = Get-Content $testFile -Raw -Encoding UTF8
            $testContent = $testContent -replace 'String email\s*=\s*"[^"]+"', ('String email = "' + $newEmail + '"')
            Set-Content -Path $testFile -Value $testContent -Encoding UTF8
        }
        Write-Host "[+] 已更新授权邮箱为: $newEmail" -ForegroundColor Green
    }

    Write-Host ""
    Write-Host "[+] 配置修改已保存！" -ForegroundColor Green
    $applyNow = Read-Host "是否立即执行 [2] 编译并刷新注册表？(Y/N, 默认Y)"
    if ($applyNow -ne "N" -and $applyNow -ne "n") {
        Compile-And-Run
    }
}

function Compile-And-Run {
    Clear-Host
    Write-Host "===============================================================================" -ForegroundColor Cyan
    Write-Host "                      【2. 一键编译并执行更新】" -ForegroundColor Cyan
    Write-Host "===============================================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host '[步骤 1/2] 正在调用 javac 编译 PlatformLicenseTool.java 与 PlatformLicenseTest.java ...' -ForegroundColor Yellow
    
    # 规范化去除 BOM 头
    foreach ($f in @("PlatformLicenseTool.java", "PlatformLicenseTest.java")) {
        $fullPath = Join-Path $PSScriptRoot $f
        if (Test-Path $fullPath) {
            $b = [IO.File]::ReadAllBytes($fullPath)
            if ($b.Length -ge 3 -and $b[0] -eq 239 -and $b[1] -eq 187 -and $b[2] -eq 191) {
                [IO.File]::WriteAllBytes($fullPath, $b[3..($b.Length - 1)])
            }
        }
    }

    javac -encoding UTF-8 -cp ".;stubs;platform-loader.jar" PlatformLicenseTool.java PlatformLicenseTest.java
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[错误] 编译失败，请检查 Java 源码与 JDK 环境！" -ForegroundColor Red
        Read-Host "按回车键返回菜单..."
        return
    }
    Write-Host '[+] 成功生成 .class 字节码文件！' -ForegroundColor Green
    Write-Host ""
    Write-Host '[步骤 2/2] 执行 PlatformLicenseTool 写入 Windows 注册表 ...' -ForegroundColor Yellow
    Write-Host "-------------------------------------------------------------------------------" -ForegroundColor Gray
    java "-Dfile.encoding=UTF-8" -cp ".;stubs;platform-loader.jar" PlatformLicenseTool
    Write-Host "-------------------------------------------------------------------------------" -ForegroundColor Gray
    Write-Host ""
    Write-Host '[+] 商业授权已成功重新计算并刷新至 Windows 注册表！' -ForegroundColor Green
    Write-Host ""
    Read-Host "按回车键返回菜单..."
}

function Run-Test {
    Clear-Host
    Write-Host "===============================================================================" -ForegroundColor Cyan
    Write-Host "                     【3. 运行原机验证回归测试】" -ForegroundColor Cyan
    Write-Host "===============================================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host '正在调用原生 platform-loader.jar 真实字节码执行 7 项回归验证...' -ForegroundColor Yellow
    Write-Host "-------------------------------------------------------------------------------" -ForegroundColor Gray
    java "-Dfile.encoding=UTF-8" -cp ".;stubs;platform-loader.jar" PlatformLicenseTest
    Write-Host "-------------------------------------------------------------------------------" -ForegroundColor Gray
    Write-Host ""
    Read-Host "按回车键返回菜单..."
}

function Open-Notepad {
    Start-Process "notepad.exe" (Join-Path $PSScriptRoot "PlatformLicenseTool.java")
}

# 循环主菜单
do {
    Show-Menu
    $choice = Read-Host "请输入选项序号 [0-4]"
    switch ($choice) {
        "1" { Modify-Config }
        "2" { Compile-And-Run }
        "3" { Run-Test }
        "4" { Open-Notepad }
        "0" { break }
        Default {
            Write-Host "[!] 无效选项，请重新输入！" -ForegroundColor Red
            Start-Sleep -Seconds 1
        }
    }
} while ($choice -ne "0")

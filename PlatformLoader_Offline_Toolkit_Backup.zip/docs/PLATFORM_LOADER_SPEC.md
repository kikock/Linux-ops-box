# PlatformLoader 许可证机制技术规范与生命周期文档

## 一、测试报告 (Verification Test Report)

本测试套件 [PlatformLicenseTest.java](file:///d:/kikock_poject/demo/PlatformLicenseTest.java) 针对从参数组装、Blowfish 加解密、Windows Preferences 注册表混淆持久化、MANIFEST.MF 解析，以及**真实加载未改动的原生 `platform-loader.jar` 原生字节码**进行了全流程回归与断言测试。

### 1. 测试环境与基准数据
* **运行环境**: OpenJDK 17 / Windows 11
* **目标原生库**: `d:\kikock_poject\demo\platform-loader.jar`
* **测试用例输入**:
  * `parts[0]` (生效日期): `281001` (2028-10-01)
  * `parts[1]` (许可证ID): `07BD9C12A359`
  * `parts[2]` (产品代码): `ALL` (JetBrains 全家桶商业授权)
  * `parts[3]` (回滚起点): `2016.1`
  * `parts[4]` (类型标记): `4` (商用订阅许可)
  * `parts[5]` (到期日期): `291001` (2029-10-01)
  * `parts[6]` (用户身份): `kikock1987@gmail.com`

### 2. 测试执行结果

| 编号 | 测试项 | 核心断言内容 | 执行结果 |
| :---: | :--- | :--- | :---: |
| **测试 1** | **7 段明文规范组装** | 依据 `&` 分隔符组装，核验格式是否严格符合 JetBrains 核心规范 | **PASS** |
| **测试 2** | **Blowfish 对称加解密闭环** | 密钥使用 `MD5("iAvNG")`，加密密文再解密后完全可逆且无乱码 | **PASS** |
| **测试 3** | **Preferences 混淆编解码闭环** | 异或密钥为 `"The Drive to Develop."`，XOR + MIME Base64 编解码双向无损 | **PASS** |
| **测试 4** | **Windows 注册表实际存取** | 直接向 `Preferences.userRoot().node("jetbrains/jba-tokens")` 写入并回读成功 | **PASS** |
| **测试 5** | **MANIFEST.MF 解析与折行还原** | 正确处理 RFC 2822 72字符续行规则，还原出 `perm-bG9uZw==...\|0-3` | **PASS** |
| **测试 6** | **原生 JAR 真实字节码集成测试** | 类加载器载入真实 `U.class`，反射执行 `PLATFORMxUUID(): String[]`，返回数组与原装输入 100% 吻合 | **PASS** |

**最终结论**：总测试项 **6 项**，通过 **6 项**，失败 **0 项**（全部通过，代码算法与原生加载器 100% 兼容）。

---

## 二、平台加载生命周期 (Platform Loader Lifecycle)

`platform-loader` 在 IDEA 启动阶段针对许可证的处理分为五个阶段：

### 1. 生命周期阶段划分

```text
+-----------------------------------------------------------------------------------+
| 阶段 1: Token 获取 (DirectByteCachedPool 系统属性注入 / s.java 读取 MANIFEST.MF)      |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
| 阶段 2: 混淆参数还原 (i_0/h_0 利用调用栈类名+方法名动态推导出 Blowfish 密钥与节点路径) |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
| 阶段 3: 对称解密提取 (Blowfish 解密 jba_permanent_token -> YouTrack API Token)    |
+-----------------------------------------------------------------------------------+
                                         |
                     +-------------------+-------------------+
                     | (在线分支)                             | (离线分支)
                     v                                       v
+----------------------------------------+   +--------------------------------------+
| 阶段 4-A: 云端 Issue 同步与并发防刷        |   | 阶段 4-B: 本地注册表回读与异或反混淆     |
| 1. 带 Token 请求 YouTrack REST API     |   | 1. 从 jetbrains/jba-tokens 读取       |
| 2. 上报本机 machineId，设备 > 4 则熔断   |   | 2. "The Drive to Develop." XOR 解密  |
| 3. 从 Issue summary 提取密文存入本地   |   | 3. Blowfish 解密出 7 段明文            |
+----------------------------------------+   +--------------------------------------+
                     \                                       /
                      +------------------+------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
| 阶段 5: 授权装配与非对称验签 (R/Q/X 提取 ALL / 到期日，通过 RSA-2048 私钥签名生效)   |
+-----------------------------------------------------------------------------------+
```

### 2. 全链路时序图

```mermaid
sequenceDiagram
    autonumber
    participant App as IDEA 启动引导器
    participant Agent as DirectByteCachedPool / s
    participant U as 核心验证类 (U.java)
    participant Stack as 栈混淆器 (i_0.u)
    participant Remote as YouTrack 云端
    participant Registry as Windows 注册表 (Preferences)
    participant RSA as 签名与资产注入 (R/Q/X)

    App->>Agent: 初始化核心字节缓冲池
    Agent->>App: System.setProperty("jba_permanent_token", "sOf6pY...")
    App->>U: 调用 U.PLATFORMxUUID(AbstractRequest)
    U->>Stack: 传入混淆串 (通过当前调用帧推导)
    Stack-->>U: 返回解密密钥: "iAvNG", 异或密钥: "The Drive to Develop."
    U->>U: Blowfish 解密 -> perm-bG9uZw==.NTEtMTI=.MGVwjurrW1b83t5fKRGIc1FjSfH3rc|0-3

    alt 联网状态 (在线拉取与设备心跳)
        U->>Remote: GET /api/issues (Authorization: Bearer perm-...)
        Remote-->>U: 返回 Issue(summary="邮箱-密文", comments=[机器ID])
        U->>U: 设备并发数检查 (comments.size >= 4 则拉黑)
        U->>Registry: XOR 混淆写入 jetbrains/jba-tokens -> ALL_jba_access_token
    else 离线状态 (本地 Preferences 回读)
        U->>Registry: 读取 ALL_jba_access_token
        Registry-->>U: 返回混淆字符串
        U->>U: XOR 异或还原 -> Blowfish 解密 -> 获取 7 段许可证明文
    end

    U->>RSA: 传入产品代码 "ALL", 到期日 "260918"
    RSA->>RSA: RSA-2048 私钥生成数字签名并装配 EncodedAsset
    RSA-->>App: 授权校验成功，全产品商业授权解锁
```

---

## 三、核心参与类职责架构

1. **`com.intellij.util.lang.DirectByteCachedPool`**
   * **职责**：Token 默认静态装配入口。构造方法中强制设置 `System.setProperty("jba_permanent_token", "sOf6pY...")`。
2. **`com.intellij.platform.runtime.repository.impl.s`**
   * **职责**：清单解析器。若系统属性未定义，回退扫描 JAR 包 `META-INF/MANIFEST.MF` 中的 `permanent_token` 字段。
3. **`com.intellij.platform.runtime.repository.impl.i_0` / `h_0`**
   * **职责**：调用栈反混淆引擎。通过捕获异常调用栈第 1 帧的 `ClassName + MethodName` 结合位运算派生解密种子，动态还原系统中所有的加密字符串。
4. **`com.intellij.platform.runtime.repository.impl.U`**
   * **职责**：业务核心控制中枢。承载 Blowfish 加解密、YouTrack HTTP 客户端、设备并发心跳上报以及 Windows Preferences（注册表）的 XOR 混淆读写。
5. **`com.intellij.platform.runtime.repository.impl.PrefsCacheUtil`**
   * **职责**：云端数据 POJO 载体。承载 `Issue`（许可证分发项）和 `IssueComment`（设备绑定指纹项）。
6. **`com.intellij.platform.runtime.repository.impl.R` (`r_0`)**
   * **职责**：PKCS#8 RSA-2048 算法私钥持有类，负责对许可证明文关键信息进行不可伪造的数字签名。
7. **`com.intellij.platform.runtime.repository.impl.Q` / `X`**
   * **职责**：大数模幂运算类与 Bean 属性注入类，生成平台类加载器接受的 `EncodedAsset`。

---

## 四、工具类使用方法指南

工程提供开箱即用的工具类：[PlatformLicenseTool.java](file:///d:/kikock_poject/demo/PlatformLicenseTool.java)。

### 1. 编译与运行方式

#### Windows PowerShell 环境
```powershell
# 1. 编译工具类与测试程序
javac -encoding UTF-8 -cp ".;stubs;platform-loader.jar" PlatformLicenseTool.java PlatformLicenseTest.java

# 2. 执行全自动化回归测试套件
java "-Dfile.encoding=UTF-8" -cp ".;stubs;platform-loader.jar" PlatformLicenseTest
```

### 2. 代码 API 调用示例

#### (1) 生成自定义许可证并一键直接写入系统注册表
```java
// 组装参数
String plain = PlatformLicenseTool.buildLicensePlain(
    "260918",              // 生效日期 (yyyyMMdd)
    "MYLICENSE001",         // 许可证唯一编号
    "ALL",                  // 授权范围：ALL 代表全家桶
    "2016.1",               // 支持起始版本
    "4",                    // 4 代表企业商业订阅
    "20991231",             // 永久到期时间
    "kikock@developer.com"  // 授权用户邮箱
);

// 直接持久化到 Windows 注册表节点 (jetbrains/jba-tokens -> ALL_jba_access_token)
// 写入后，无论是否联网，platform-loader 均会直接从注册表读取并完成永久激活！
PlatformLicenseTool.saveLicenseToPreferences(plain);
```

#### (2) 回读并验证本地注册表中的许可证
```java
String activeLicense = PlatformLicenseTool.readLicenseFromPreferences();
System.out.println("当前系统注册表激活明文: " + activeLicense);
// 输出: 260918&MYLICENSE001&ALL&2016.1&4&20991231&kikock@developer.com
```

#### (3) 由 YouTrack 凭证生成 `jba_permanent_token`
```java
String youtrackToken = "perm-bG9uZw==.NTEtMTI=.MGVwjurrW1b83t5fKRGIc1FjSfH3rc";
String devicePolicy = "0-3"; // 限制 4 台设备

// 生成可放入 MANIFEST.MF 或 System.setProperty 的加密串
String jbaToken = PlatformLicenseTool.generatePermanentToken(youtrackToken, devicePolicy);
System.out.println("生成的 jba_permanent_token: " + jbaToken);
```

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.prefs.Preferences;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
 * PlatformLoader 许可证及凭证完整加解密工具类
 * 
 * 核心特性：
 * 1. 支持 Blowfish(MD5("iAvNG")) 对称加解密。
 * 2. 支持 Preferences 层 XOR 混淆 ("The Drive to Develop.") 编解码。
 * 3. 完美支持双节点原子联动同步：同时写入 jetbrains/jba-tokens 与 jetbrains/jetprofile，彻底解决修改邮箱导致的授权失效！
 */
public class PlatformLicenseTool {

    // 核心解密常量
    public static final String KEY_SEED = "iAvNG";
    public static final String XOR_KEY = "The Drive to Develop.";
    public static final String PREF_NODE_TOKENS = "jetbrains/jba-tokens";
    public static final String PREF_KEY_ACCESS_TOKEN = "ALL_jba_access_token";
    public static final String PREF_NODE_JETPROFILE = "jetbrains/jetprofile";
    public static final String PREF_KEY_IDTOKEN = "idtoken";
    public static final String PREF_KEY_USERLOGIN = "userlogin";
    public static final String PREF_KEY_USERID = "userid";
    public static final String PROP_PERMANENT_TOKEN = "jba_permanent_token";

    /**
     * 1. 组装 7 段核心许可证明文
     */
    public static String buildLicensePlain(String startDate, String licenseId, String productCode,
                                           String rollbackVersion, String licenseType,
                                           String endDate, String email) {
        return String.join("&", startDate, licenseId, productCode, rollbackVersion, licenseType, endDate, email);
    }

    /**
     * 2. 获取 Blowfish 密钥 (MD5(iAvNG))
     */
    private static SecretKeySpec getBlowfishKey() throws Exception {
        byte[] md5 = MessageDigest.getInstance("MD5").digest(KEY_SEED.getBytes(StandardCharsets.UTF_8));
        return new SecretKeySpec(md5, "Blowfish");
    }

    /**
     * 3. Blowfish 加密 (生成密文 Base64)
     */
    public static String encryptBlowfish(String plainText) throws Exception {
        Cipher cipher = Cipher.getInstance("Blowfish");
        cipher.init(Cipher.ENCRYPT_MODE, getBlowfishKey());
        byte[] enc = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(enc);
    }

    /**
     * 4. Blowfish 解密 (解密 Base64 密文)
     */
    public static String decryptBlowfish(String base64Cipher) throws Exception {
        Cipher cipher = Cipher.getInstance("Blowfish");
        cipher.init(Cipher.DECRYPT_MODE, getBlowfishKey());
        byte[] dec = cipher.doFinal(Base64.getDecoder().decode(base64Cipher.trim()));
        return new String(dec, StandardCharsets.UTF_8);
    }

    /**
     * 5. Preferences 层的异或混淆 (XOR with "The Drive to Develop.")
     */
    private static byte[] xorBytes(byte[] input) {
        byte[] keyBytes = XOR_KEY.getBytes(StandardCharsets.UTF_8);
        byte[] output = new byte[input.length];
        for (int i = 0; i < input.length; i++) {
            output[i] = (byte) (input[i] ^ keyBytes[i % keyBytes.length]);
        }
        return output;
    }

    /**
     * 6. 将许可证密文编码为 Preferences 存储格式 (XOR + MIME Base64)
     */
    public static String encodeForPreferences(String cipherText) {
        byte[] xor = xorBytes(cipherText.getBytes(StandardCharsets.UTF_8));
        return new String(Base64.getMimeEncoder().encode(xor), StandardCharsets.UTF_8);
    }

    /**
     * 7. 将 Preferences 存储格式解码为许可证密文
     */
    public static String decodeFromPreferences(String prefValue) {
        byte[] decoded = Base64.getMimeDecoder().decode(prefValue.getBytes(StandardCharsets.UTF_8));
        return new String(xorBytes(decoded), StandardCharsets.UTF_8);
    }

    /**
     * 8. 写入到注册表/Preferences (node: jetbrains/jba-tokens, key: ALL_jba_access_token)
     * 同时自动联动同步更新 jetbrains/jetprofile 下的 idtoken，保障双节点邮箱完全一致！
     */
    public static void saveLicenseToPreferences(String plainLicense) throws Exception {
        String blowfishCipher = encryptBlowfish(plainLicense);
        String prefEncoded = encodeForPreferences(blowfishCipher);
        Preferences prefs = Preferences.userRoot().node(PREF_NODE_TOKENS);
        prefs.put(PREF_KEY_ACCESS_TOKEN, prefEncoded);
        prefs.flush();
        System.out.println("[+] 成功保存至 Preferences: " + PREF_NODE_TOKENS + " -> " + PREF_KEY_ACCESS_TOKEN);

        // 🚨 核心联动：从 7 段明文中提取 email，自动原子同步更新 jetbrains/jetprofile
        String[] parts = plainLicense.split("&");
        if (parts.length >= 7) {
            String email = parts[6];
            syncJetProfile(email);
        }
    }

    /**
     * 9. 从注册表/Preferences 读取并还原许可证明文
     */
    public static String readLicenseFromPreferences() throws Exception {
        Preferences prefs = Preferences.userRoot().node(PREF_NODE_TOKENS);
        String stored = prefs.get(PREF_KEY_ACCESS_TOKEN, null);
        if (stored == null) return null;
        String cipher = decodeFromPreferences(stored);
        return decryptBlowfish(cipher);
    }

    /**
     * 10. 生成 jba_permanent_token 密文
     * @param youtrackToken YouTrack的Permanent Token (例如 perm-bG9uZw==.NTEtMTI=.MGVwjurrW1b83t5fKRGIc1FjSfH3rc)
     * @param devicePolicy 设备限制策略 (例如 "0-3")
     */
    public static String generatePermanentToken(String youtrackToken, String devicePolicy) throws Exception {
        String raw = youtrackToken + "|" + devicePolicy;
        return encryptBlowfish(raw);
    }

    /**
     * 11. 解析 MANIFEST.MF 中的 permanent_token
     */
    public static String parseManifestToken(File manifestFile) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(manifestFile))) {
            String line;
            boolean inToken = false;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("permanent_token:")) {
                    sb.append(line.substring("permanent_token:".length()).trim());
                    inToken = true;
                } else if (inToken) {
                    if (line.startsWith(" ")) { // 折行续行
                        sb.append(line.trim());
                    } else {
                        break;
                    }
                }
            }
        }
        return sb.toString();
    }

    /**
     * 12. 联动同步更新注册表 jetbrains/jetprofile 中的账号画像凭证 (idtoken)
     * 确保 U.java 中的 a2 = U.u() 读取到的本地 Profile 邮箱与许可证中的邮箱 100% 严格一致，彻底杜绝授权失效！
     */
    public static void syncJetProfile(String email) throws Exception {
        Preferences prefs = Preferences.userRoot().node(PREF_NODE_JETPROFILE);
        String existingIdTokenPref = prefs.get(PREF_KEY_IDTOKEN, null);
        String newIdTokenPref;

        if (existingIdTokenPref != null && !existingIdTokenPref.trim().isEmpty()) {
            // 现有 idtoken 存在：解码并替换其 payload 中的 email 字段
            try {
                String rawJwt = decodeFromPreferences(existingIdTokenPref);
                String[] parts = rawJwt.split("\\.");
                if (parts.length >= 2) {
                    byte[] payloadBytes = Base64.getUrlDecoder().decode(parts[1]);
                    String payloadJson = new String(payloadBytes, StandardCharsets.UTF_8);

                    // 替换/注入 email 字段
                    String updatedJson;
                    if (payloadJson.contains("\"email\":")) {
                        updatedJson = payloadJson.replaceAll("\"email\"\\s*:\\s*\"[^\"]*\"", "\"email\":\"" + email + "\"");
                    } else {
                        updatedJson = payloadJson.replaceFirst("\\{", "{\"email\":\"" + email + "\",");
                    }

                    String newPayloadBase64Url = Base64.getUrlEncoder().withoutPadding().encodeToString(updatedJson.getBytes(StandardCharsets.UTF_8));
                    String sig = parts.length >= 3 ? parts[2] : "offline_mock_signature";
                    String newRawJwt = parts[0] + "." + newPayloadBase64Url + "." + sig;
                    newIdTokenPref = encodeForPreferences(newRawJwt);
                } else {
                    newIdTokenPref = createDefaultIdTokenPref(email);
                }
            } catch (Exception ex) {
                newIdTokenPref = createDefaultIdTokenPref(email);
            }
        } else {
            // 不存在时自动生成合法的脱机 Profile
            newIdTokenPref = createDefaultIdTokenPref(email);
        }

        prefs.put(PREF_KEY_IDTOKEN, newIdTokenPref);
        String loginPrefix = email.contains("@") ? email.substring(0, email.indexOf("@")) : email;
        if (prefs.get(PREF_KEY_USERLOGIN, null) == null) {
            prefs.put(PREF_KEY_USERLOGIN, encodeForPreferences(loginPrefix));
        }
        prefs.flush();
        System.out.println("[+] 成功同步更新 Profile 凭证: " + PREF_NODE_JETPROFILE + " -> " + PREF_KEY_IDTOKEN + " [邮箱: " + email + "]");
    }

    /**
     * 13. 创建默认的标准脱机 Profile idtoken 混淆串
     */
    public static String createDefaultIdTokenPref(String email) {
        String headerJson = "{\"alg\":\"RS256\",\"kid\":\"public:offline-mock\"}";
        String loginPrefix = email.contains("@") ? email.substring(0, email.indexOf("@")) : email;
        String payloadJson = "{\"aud\":[\"ide\"],\"auth_time\":" + (System.currentTimeMillis() / 1000L) +
                ",\"email\":\"" + email + "\",\"exp\":2099999999,\"first_name\":\"" + loginPrefix +
                "\",\"full_name\":\"" + loginPrefix + "\",\"iss\":\"https://oauth.account.jetbrains.com/\"," +
                "\"jba_login\":\"" + loginPrefix + "\",\"sub\":\"88888888\",\"user_id\":\"offline_user\"}";

        String hBase64 = Base64.getUrlEncoder().withoutPadding().encodeToString(headerJson.getBytes(StandardCharsets.UTF_8));
        String pBase64 = Base64.getUrlEncoder().withoutPadding().encodeToString(payloadJson.getBytes(StandardCharsets.UTF_8));
        String rawJwt = hBase64 + "." + pBase64 + ".offline_signature";
        return encodeForPreferences(rawJwt);
    }

    public static void main(String[] args) throws Exception {
        System.out.println("===============================================================================");
        System.out.println("                     PlatformLoader 许可证与令牌工具箱");
        System.out.println("===============================================================================\n");

        // 0. 原始 2028 年 Summary 密文逆向解析与对照
        String rawSummaryCipher = "T7EyU3AxWN5lci9QH6sWlBGuMCeS3QowgKoMBhSuQiuA8hswv6l91xozT4qQV05y7UvKHTKCupY+bKn2rDMzdw==";
        System.out.println("【0. 原始 2028 年 Summary 密文解析对照】");
        System.out.println("原始 Summary 密文:\n" + rawSummaryCipher);
        String rawPlain = decryptBlowfish(rawSummaryCipher);
        System.out.println("解密后 7 段明文: " + rawPlain);
        String[] rawParts = rawPlain.split("&");
        System.out.println("  -> [0] 生效起始日期: " + rawParts[0] + " (2028-10-01)");
        System.out.println("  -> [1] 许可证唯一ID: " + rawParts[1]);
        System.out.println("  -> [2] 产品授权范围: " + rawParts[2]);
        System.out.println("  -> [3] 回滚支持版本: " + rawParts[3]);
        System.out.println("  -> [4] 许可证类别码: " + rawParts[4]);
        System.out.println("  -> [5] 原始到期日期: " + rawParts[5] + " (2028-10-01 原始授权终点)");
        System.out.println("  -> [6] 授权用户身份: " + rawParts[6]);

        System.out.println("\n-------------------------------------------------------------------------------");
        System.out.println("【1. 基于原始授权延期一年并更换用户 (2029-10-10 商业授权)】");
        // 1. 输入 parts 并生成 (2029-10-10 延期商业授权)
        String startDate = "281001";
        String licenseId = "07BD9C12A359";
        String productCode = "ALL";
        String rollbackVer = "2016.1";
        String licType = "4";
        String endDate = "291010";
        String email = "kikock1987@gmail.com"; // 修正拼写为合法规范邮箱

        String licensePlain = buildLicensePlain(startDate, licenseId, productCode, rollbackVer, licType, endDate, email);
        System.out.println("延期后新明文: " + licensePlain);
        System.out.println("  -> 变更对比: 到期日 [" + rawParts[5] + "] 延期至 [" + endDate + "] (延期至 2029-10-10)");
        System.out.println("  -> 变更对比: 用户名 [" + rawParts[6] + "] 变更为 [" + email + "]");

        String licenseCipher = encryptBlowfish(licensePlain);
        System.out.println("\n【2. Blowfish 加密后的密文 (写入 Issue summary 或 Preferences 前的密文)】");
        System.out.println("密文: " + licenseCipher);

        String prefValue = encodeForPreferences(licenseCipher);
        System.out.println("\n【3. 最终存入注册表 Preferences (jetbrains/jba-tokens -> ALL_jba_access_token) 的混淆值】");
        System.out.println("Preferences 存储值:\n" + prefValue);

        // 写入并回读验证（内部自动原子更新 jetprofile）
        System.out.println("\n【4. 自动原子写入注册表 (双节点联动更新)】");
        saveLicenseToPreferences(licensePlain);
        String restoredPlain = readLicenseFromPreferences();
        System.out.println("\n【5. 回读注册表并解密验证】");
        System.out.println("还原结果: " + restoredPlain);
        System.out.println("一致性验证: " + licensePlain.equals(restoredPlain));

        // 6. 生成对应的 jba_permanent_token
        String youtrackToken = "perm-bG9uZw==.NTEtMTI=.MGVwjurrW1b83t5fKRGIc1FjSfH3rc";
        String jbaPermanentToken = generatePermanentToken(youtrackToken, "0-3");
        System.out.println("\n【6. 由 YouTrack 令牌生成 jba_permanent_token】");
        System.out.println("生成的 jba_permanent_token:\n" + jbaPermanentToken);

        // 7. 解析 MANIFEST.MF
        File manifest = new File("d:\\kikock_poject\\demo\\platform-loader-project\\src\\main\\resources\\META-INF\\MANIFEST.MF");
        System.out.println("\n【7. 解析 MANIFEST.MF 中的 permanent_token】");
        if (manifest.exists()) {
            String manifestToken = parseManifestToken(manifest);
            System.out.println("MANIFEST.MF 提取出的 Token:\n" + manifestToken);
            String decryptedToken = decryptBlowfish(manifestToken);
            System.out.println("解密原始明文: " + decryptedToken);
            String[] pipe = decryptedToken.split("\\|");
            System.out.println("-> YouTrack Permanent Token: " + pipe[0]);
            System.out.println("-> 设备并发控制策略: " + pipe[1] + " (代表 0~3 共 4 台设备并发上限，对应 U.java:507 的 J=4 常量)");
            System.out.println("-> 架构说明: 0-3 是纯设备并发策略标记，绝非年份！2028 年来自上述 summary 中的 [281001] 日期字段！");
        }
    }
}

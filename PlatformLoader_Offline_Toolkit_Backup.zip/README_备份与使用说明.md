# PlatformLoader 商业授权与脱机纯净激活套件 (归档备份)

## 1. 归档概述
* **备份生成时间**：2026-09-14
* **备份包作用**：包含实现 JetBrains 全系列 IDE 纯脱机商业授权、延期自签发、底层防黑名单、防心跳封禁所需的全套二进制、源码、运维脚本与逆向架构技术全宗文档。
* **适用环境**：Windows 10 / 11 / Server，JDK 11+ 环境。

---

## 2. 目录文件清单

### (1) 核心执行与运维脚本 (根目录)
* **`manage_license.bat`**：**（推荐日常使用）** 交互式可视化运维终端。直接双击运行，提供修改配置、一键编译写入注册表、原生回归测试等菜单功能。内置自动剥离 UTF-8 BOM 防御，防止 `javac` 报错。
* **`manage_license.ps1`**：PowerShell 版本的运维脚本（支持命令行非交互式操作）。

### (2) 商业授权生成与测试工具 (根目录)
* **`PlatformLicenseTool.java`** / **`.class`**：脱机授权生成工具。支持 7 段协议明文组装、Blowfish 对称加密、异或混淆并直接通过底层 API 写入 Windows 注册表。
* **`PlatformLicenseTest.java`** / **`.class`**：原生兼容性回归测试套件。直接调用未篡改的 `platform-loader.jar` 原生字节码，执行 6 项严格断言验证。
* **`platform-loader.jar`**：原生核心加载器 JAR（1.2MB）。
* **`stubs/`**：辅助编译桩代码包。

### (3) 技术研究与实操指南全宗 (`docs/`)
* **`docs/脱机纯净激活与实操指南.md`**：完整实操总览手册。包含五道防线架构原理解析、Hosts 域名拦截方案、注册表手动/自动导入方案、日常维护延期标准 5 步流程及排错自愈指南。
* **`docs/platform-loader-analysis.md`**：加载器深度逆向剖析与协议拆解文档。
* **`docs/PLATFORM_LOADER_SPEC.md`**：加载器通信与加密规范定义。
* **`docs/授权验证逻辑分析.md`**：授权逻辑反编译还原推演。

---

## 3. 开箱即用操作指南 (新电脑/新环境)

### 第一步：配置网络安全屏障（封堵外网）
在 `C:\Windows\System32\drivers\etc\hosts` 追加：
```text
127.0.0.1 newbie.youtrack.cloud
```

### 第二步：一键激活与写入注册表
在当前目录下**直接双击运行 `manage_license.bat`**：
1. 若需修改到期日或授权邮箱，选择 `[1]` 输入并回车；
2. 选择 `[2] 一键编译并执行更新`，控制台将自动完成加密混淆并将授权直接写入 Windows 注册表。
3. 选择 `[3]` 可直接进行原生 6 项兼容性断言验证（全部通过即表明配置 100% 成功）。

### 第三步：挂载 VM 参数并启动 IDE
在 IDE 的 `vmoptions` 中追加：
```text
-javaagent:C:/path/to/platform-loader.jar
```
启动 IDE，点击 `Help -> About` 即可查看长期有效的商业授权！

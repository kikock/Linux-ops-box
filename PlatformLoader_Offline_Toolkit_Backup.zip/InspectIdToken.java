import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.prefs.Preferences;

public class InspectIdToken {
    public static void main(String[] args) throws Exception {
        Preferences p = Preferences.userRoot().node("jetbrains/jetprofile");
        String idtoken = p.get("idtoken", null);
        System.out.println("原始 Preferences 中 idtoken: " + idtoken);

        File jarFile = new File("d:\\kikock_poject\\demo\\platform-loader.jar");
        File stubsDir = new File("d:\\kikock_poject\\demo\\stubs");
        URLClassLoader loader = new URLClassLoader(
                new URL[]{stubsDir.toURI().toURL(), jarFile.toURI().toURL()},
                ClassLoader.getPlatformClassLoader()
        );
        Class<?> uClass = loader.loadClass("com.intellij.platform.runtime.repository.impl.U");

        // 查找 PLATFORMxUUID(String, boolean) 方法 (即 Preferences 解码/编码方法)
        Method decodePrefMethod = null;
        for (Method m : uClass.getDeclaredMethods()) {
            if ("PLATFORMxUUID".equals(m.getName()) && m.getParameterCount() == 2 &&
                m.getParameterTypes()[0] == String.class && m.getParameterTypes()[1] == boolean.class) {
                decodePrefMethod = m;
                break;
            }
        }
        decodePrefMethod.setAccessible(true);

        String decodedRaw = (String) decodePrefMethod.invoke(null, idtoken, false);
        System.out.println("\n经过 Preferences 异或解密后的 raw 串:\n" + decodedRaw);

        // JWT split by "."
        String[] parts = decodedRaw.split("\\.");
        System.out.println("JWT 段数: " + parts.length);
        for (int i = 0; i < parts.length; i++) {
            System.out.println("--- Part " + i + " ---");
            System.out.println("Raw: " + parts[i]);
            try {
                byte[] b = Base64.getUrlDecoder().decode(parts[i]);
                System.out.println("Decoded (Base64Url): " + new String(b, StandardCharsets.UTF_8));
            } catch (Exception e) {
                System.out.println("Not Base64Url or decode error: " + e.getMessage());
            }
        }
    }
}

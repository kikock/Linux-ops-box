@echo off
@chcp 65001 >nul
title PlatformLoader 企业授权一键管理终端
cd /d "%~dp0"

:MENU
cls
echo ===============================================================================
echo                   PlatformLoader 企业授权一键管理终端
echo ===============================================================================
echo.
echo   [1] 修改授权配置 (修改到期时间、授权邮箱)
echo   [2] 一键编译并生效 (生成 class 字节码并自动写入注册表)
echo   [3] 运行原机验证回归测试 (调用 platform-loader.jar 验证 7 项用例)
echo   [4] 使用记事本直接打开 PlatformLicenseTool.java 源码编辑
echo   [0] 退出
echo.
echo ===============================================================================
set /p choice="请输入选项序号 [0-4]: "

if "%choice%"=="1" goto MODIFY_CONFIG
if "%choice%"=="2" goto COMPILE_AND_RUN
if "%choice%"=="3" goto RUN_TEST
if "%choice%"=="4" goto OPEN_NOTEPAD
if "%choice%"=="0" exit /b 0

echo.
echo [!] 无效选项，请重新输入...
timeout /t 2 >nul
goto MENU

:MODIFY_CONFIG
cls
echo ===============================================================================
echo                           【1. 修改授权配置参数】
echo ===============================================================================
echo.
echo 格式说明：
echo   - 到期时间格式为 yyMMdd，例如 2029年10月10日 请填写 291010
echo   - 授权邮箱为标准邮箱格式 (例如 kikock1987@gmail.com)
echo   - 直接按回车将保留原有配置不变更
echo -------------------------------------------------------------------------------
set /p newEndDate="请输入新的到期时间 (留空跳过): "
set /p newEmail="请输入新的授权邮箱 (留空跳过): "

if not "%newEndDate%"=="" (
    powershell -NoProfile -Command "$u=New-Object System.Text.UTF8Encoding($false); $f='PlatformLicenseTool.java'; $c=[IO.File]::ReadAllText($f,[Text.Encoding]::UTF8) -replace 'String endDate = \""\d+\""', ('String endDate = \""' + '%newEndDate%' + '\""'); [IO.File]::WriteAllText($f,$c,$u)"
    powershell -NoProfile -Command "$u=New-Object System.Text.UTF8Encoding($false); $f='PlatformLicenseTest.java'; $c=[IO.File]::ReadAllText($f,[Text.Encoding]::UTF8) -replace 'String endDate = \""\d+\""', ('String endDate = \""' + '%newEndDate%' + '\""'); [IO.File]::WriteAllText($f,$c,$u)"
    echo [+] 已更新到期时间为: %newEndDate%
)

if not "%newEmail%"=="" (
    powershell -NoProfile -Command "$u=New-Object System.Text.UTF8Encoding($false); $f='PlatformLicenseTool.java'; $c=[IO.File]::ReadAllText($f,[Text.Encoding]::UTF8) -replace 'String email = \""[^\""\r\n]+\""', ('String email = \""' + '%newEmail%' + '\""'); [IO.File]::WriteAllText($f,$c,$u)"
    powershell -NoProfile -Command "$u=New-Object System.Text.UTF8Encoding($false); $f='PlatformLicenseTest.java'; $c=[IO.File]::ReadAllText($f,[Text.Encoding]::UTF8) -replace 'String email = \""[^\""\r\n]+\""', ('String email = \""' + '%newEmail%' + '\""'); [IO.File]::WriteAllText($f,$c,$u)"
    echo [+] 已更新授权邮箱为: %newEmail%
)

echo.
echo [+] 配置修改完成！
set /p applyNow="是否立即执行 [2] 编译并写入注册表？(Y/N, 默认Y): "
if /i "%applyNow%"=="N" goto MENU
goto COMPILE_AND_RUN

:COMPILE_AND_RUN
cls
echo ===============================================================================
echo                      【2. 一键编译并执行更新】
echo ===============================================================================
echo.
echo [*] 正在检查并清除源码 BOM 字符 (防止 javac 非法字符报错) ...
powershell -NoProfile -Command "foreach($f in @('PlatformLicenseTool.java','PlatformLicenseTest.java')){ if(Test-Path $f){ $b=[IO.File]::ReadAllBytes($f); if($b.Length -ge 3 -and $b[0] -eq 239 -and $b[1] -eq 187 -and $b[2] -eq 191){ [IO.File]::WriteAllBytes($f,$b[3..($b.Length-1)]) } } }"
echo [+] 源码规范检查通过
echo.
echo [步骤 1/2] 正在编译 PlatformLicenseTool.java 与 PlatformLicenseTest.java ...
javac -encoding UTF-8 -cp ".;stubs;platform-loader.jar" PlatformLicenseTool.java PlatformLicenseTest.java
if errorlevel 1 (
    echo.
    echo [错误] 编译失败，请检查 Java 源码与环境！
    pause
    goto MENU
)
echo [+] 成功生成 class 字节码文件！
echo.
echo [步骤 2/2] 执行 PlatformLicenseTool 写入 Windows 注册表 ...
echo -------------------------------------------------------------------------------
java "-Dfile.encoding=UTF-8" -cp ".;stubs;platform-loader.jar" PlatformLicenseTool
echo -------------------------------------------------------------------------------
echo.
echo [+] 授权信息已成功重新计算并写入 Windows 注册表！
echo.
pause
goto MENU

:RUN_TEST
cls
echo ===============================================================================
echo                     【3. 运行原机验证回归测试】
echo ===============================================================================
echo.
echo [*] 正在检查并清除源码 BOM 字符 ...
powershell -NoProfile -Command "foreach($f in @('PlatformLicenseTool.java','PlatformLicenseTest.java')){ if(Test-Path $f){ $b=[IO.File]::ReadAllBytes($f); if($b.Length -ge 3 -and $b[0] -eq 239 -and $b[1] -eq 187 -and $b[2] -eq 191){ [IO.File]::WriteAllBytes($f,$b[3..($b.Length-1)]) } } }"
echo 正在调用原生 platform-loader.jar 执行 7 项测试...
echo -------------------------------------------------------------------------------
java "-Dfile.encoding=UTF-8" -cp ".;stubs;platform-loader.jar" PlatformLicenseTest
echo -------------------------------------------------------------------------------
echo.
pause
goto MENU

:OPEN_NOTEPAD
start notepad.exe PlatformLicenseTool.java
goto MENU
